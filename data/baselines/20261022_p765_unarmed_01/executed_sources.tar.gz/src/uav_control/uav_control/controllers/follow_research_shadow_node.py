"""Extend the existing shadow node with one selectable research algorithm."""

from functools import partial

import rclpy

from uav_control.controllers.follow_mpc_shadow_node import (
    FollowMpcShadowNode, ShadowResearchRunner, make_shadow_request,
)
from uav_control.controllers.follow_research_solver import FollowResearchSolver
from uav_control.guidance.follow_minco_optimizer import MincoConfig


class FollowResearchShadowNode(FollowMpcShadowNode):
    """Reuse all synchronization, subscriptions, task handling and admission checks."""

    node_name = 'follow_research_shadow_node'

    def make_runner(self, config):
        """Inject a single solver and explicit execution boundary into the original runner."""
        for name, default in (('research_mode', 'greedy_minco'), ('execution_lead', .15),
                              ('minco_mode', 'qt'), ('minco_iterations', 2),
                              ('visibility_weight', 20.), ('minco_engine', 'legacy'),
                              ('initializer_strategy', 'legacy'), ('greedy_strategy', 'D'),
                              ('dynamic_endpoint', True), ('fast_feasible_seed', True),
                              ('greedy_minimum_distance', 3.), ('greedy_maximum_distance', 10.),
                              ('p32_profile_every', 0), ('p32_detailed_diagnostics', False),
                              ('p32_initialization_cap', .012), ('short_horizon', 1.2),
                              ('short_rolling_hint', True), ('p43_refinement', 'qt'),
                              ('p44_ablation', 'D'), ('p44_refinement', 'none'),
                              ('follow_guided_refinement', 'none'),
                              ('follow_guided_response_time', .5),
                              ('follow_guided_optimization_budget', .025),
                              ('p47_terminal_mode', 'qva'), ('p47_refinement', True),
                              ('p47_scheduling', 'adaptive'), ('p51_online_budget_guard', False),
                              ('follow_reference_mode', 'target')):
            self.declare_parameter(name, default)
        mode = self.get_parameter('research_mode').value
        optimizer = MincoConfig(mode=self.get_parameter('minco_mode').value,
                                maximum_iterations=self.get_parameter('minco_iterations').value,
                                visibility_weight=self.get_parameter('visibility_weight').value,
                                budget=config.solve_budget)
        optimizer.validate()
        engine = self.get_parameter('minco_engine').value
        engines = ('legacy', 'p31', 'p32', 'p32_short', 'p33_progress',
                   'p41_tracking', 'p43_fast', 'p44_adaptive', 'follow_guided_minco',
                   'p47_follow_guided')
        if engine not in engines:
            raise ValueError('unsupported minco engine')
        fast, greedy = None, None
        initialization = self.get_parameter('initializer_strategy').value
        if engine in engines[1:]:
            from uav_control.guidance.fast_follow_minco import FastConfig
            from uav_control.guidance.adaptive_follow_initializer import GreedyConfig
            fast = FastConfig(freshness_budget=True, fast_feasible_seed=bool(
                self.get_parameter('fast_feasible_seed').value))
            greedy = GreedyConfig(strategy=self.get_parameter('greedy_strategy').value,
                                  dynamic_endpoint=bool(
                                      self.get_parameter('dynamic_endpoint').value),
                                  minimum_distance=float(
                                      self.get_parameter('greedy_minimum_distance').value),
                                  maximum_distance=float(
                                      self.get_parameter('greedy_maximum_distance').value))
        elif initialization != 'legacy':
            raise ValueError('new initialization requires explicit p31 engine')
        solver = FollowResearchSolver(mode, config, optimizer, fast, greedy, initialization)
        if engine in engines[2:]:
            if mode != 'greedy_minco':
                raise ValueError('p32 requires greedy_minco shadow mode')
            if engine in ('p32_short', 'p33_progress', 'p41_tracking', 'p43_fast',
                          'p44_adaptive', 'follow_guided_minco', 'p47_follow_guided'):
                from uav_control.controllers.short_follow_solver import ShortHorizonFollowSolver
                if engine == 'p47_follow_guided':
                    from uav_control.controllers.follow_guided_feasible import P47FollowGuidedMinco
                    selected_solver = P47FollowGuidedMinco
                elif engine == 'follow_guided_minco':
                    from uav_control.controllers.direct_reference_minco import FollowGuidedMinco
                    selected_solver = FollowGuidedMinco
                elif engine == 'p44_adaptive':
                    from uav_control.controllers.p44_follow_solver import P44FollowSolver
                    selected_solver = P44FollowSolver
                elif engine == 'p43_fast':
                    from uav_control.controllers.p43_follow_solver import P43FollowSolver
                    selected_solver = P43FollowSolver
                elif engine == 'p41_tracking':
                    from uav_control.controllers.progress_follow_solver import TrackingFollowSolver
                    selected_solver = TrackingFollowSolver
                elif engine == 'p33_progress':
                    from uav_control.controllers.progress_follow_solver import ProgressFollowSolver
                    selected_solver = ProgressFollowSolver
                else:
                    selected_solver = ShortHorizonFollowSolver
                extra = (dict(refinement=self.get_parameter('p43_refinement').value)
                         if engine == 'p43_fast' else {})
                if engine == 'p44_adaptive':
                    extra = dict(ablation=self.get_parameter('p44_ablation').value,
                                 refinement=self.get_parameter('p44_refinement').value)
                elif engine == 'p47_follow_guided':
                    from uav_control.guidance.follow_rollout import FollowRolloutConfig
                    extra = dict(
                        terminal_mode=self.get_parameter('p47_terminal_mode').value,
                        refinement=self.get_parameter('p47_refinement').value,
                        scheduling=self.get_parameter('p47_scheduling').value,
                        online_budget_guard=self.get_parameter('p51_online_budget_guard').value,
                        rollout_config=FollowRolloutConfig(response_time=float(
                            self.get_parameter('follow_guided_response_time').value),
                            reference_mode=self.get_parameter('follow_reference_mode').value))
                elif engine == 'follow_guided_minco':
                    from uav_control.guidance.follow_rollout import FollowRolloutConfig
                    extra = dict(
                        refinement=self.get_parameter('follow_guided_refinement').value,
                        rollout_config=FollowRolloutConfig(response_time=float(
                            self.get_parameter('follow_guided_response_time').value)),
                        optimization_budget=float(
                            self.get_parameter('follow_guided_optimization_budget').value),
                        maximum_iterations=int(self.get_parameter('minco_iterations').value))
                solver = selected_solver(
                    solver.model, duration=float(self.get_parameter('short_horizon').value),
                    rolling=bool(self.get_parameter('short_rolling_hint').value),
                    wall_clock=lambda: self.get_clock().now().nanoseconds/1e9, **extra)
            else:
                from uav_control.controllers.realtime_follow_solver import RealtimeFollowSolver
                solver = RealtimeFollowSolver(solver.model, optimizer, wall_clock=lambda: (
                    self.get_clock().now().nanoseconds/1e9), profile_every=int(
                        self.get_parameter('p32_profile_every').value), detailed=bool(
                        self.get_parameter('p32_detailed_diagnostics').value),
                    initialization_cap=float(
                            self.get_parameter('p32_initialization_cap').value))
        factory = make_shadow_request
        if mode != 'mpc_seed':
            lead = float(self.get_parameter('execution_lead').value)
            if not 0 <= lead <= .3:
                raise ValueError('execution lead must be in [0, .3]')
            factory = partial(make_shadow_request, execution_lead=lead)
        return ShadowResearchRunner(config, self.adapter, self.pool, self._publish_event,
                                    float(self.get_parameter('shadow_rate_hz').value),
                                    solver, factory)


def main(args=None):
    """Run a single research mode, keeping all flight control in the original tracker."""
    rclpy.init(args=args)
    node = None
    try:
        node = FollowResearchShadowNode()
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if node is not None:
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
