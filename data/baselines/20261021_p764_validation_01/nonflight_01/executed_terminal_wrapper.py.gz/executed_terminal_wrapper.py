#!/usr/bin/env python3
import json, os, pathlib, subprocess, sys
root = pathlib.Path(os.environ['UAV_USV_RESEARCH_DIRECTORY'])
title = next(a.split('=', 1)[1] for a in sys.argv if a.startswith('--title='))
with (root/(title.replace(' ', '_')+'.txt')).open('x') as log:
    child = subprocess.Popen(sys.argv[sys.argv.index('--')+1:], stdout=log,
                             stderr=log, stdin=subprocess.PIPE, start_new_session=True)
raw = pathlib.Path('/proc/'+str(child.pid)+'/stat').read_text()
fields = raw[raw.rfind(')')+2:].split()
with (root/'component_identities.jsonl').open('a') as stream:
    stream.write(json.dumps(dict(pid=child.pid, pgid=int(fields[2]), start=fields[19]))+'\n')
